"""Elder Trading System - Routes Package"""
from routes.api import api
